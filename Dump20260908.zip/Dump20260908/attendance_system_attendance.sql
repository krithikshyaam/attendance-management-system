-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: attendance_system
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `attendance_id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `subject_id` int NOT NULL,
  `teacher_id` int NOT NULL,
  `attendance_date` date NOT NULL,
  `period_no` tinyint NOT NULL,
  `status` enum('Present','Absent','Late','Leave') NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `marked_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `student_id` (`student_id`,`attendance_date`,`period_no`),
  KEY `fk_attendance_subject` (`subject_id`),
  KEY `fk_attendance_teacher` (`teacher_id`),
  KEY `fk_attendance_period` (`period_no`),
  CONSTRAINT `fk_attendance_period` FOREIGN KEY (`period_no`) REFERENCES `period_master` (`period_no`),
  CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `student` (`student_id`),
  CONSTRAINT `fk_attendance_subject` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`),
  CONSTRAINT `fk_attendance_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (1,1,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(2,2,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(3,3,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(4,4,1,1,'2026-09-07',1,'Absent','Not present','2026-09-06 16:09:27'),(5,5,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(6,6,1,1,'2026-09-07',1,'Late','10 minutes late','2026-09-06 16:09:27'),(7,7,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(8,8,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(9,9,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(10,10,1,1,'2026-09-07',1,'Absent',NULL,'2026-09-06 16:09:27'),(11,11,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(12,12,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(13,13,1,1,'2026-09-07',1,'Leave','Approved leave','2026-09-06 16:09:27'),(14,14,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(15,15,1,1,'2026-09-07',1,'Present',NULL,'2026-09-06 16:09:27'),(16,1,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(17,2,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(18,3,2,2,'2026-09-07',2,'Absent',NULL,'2026-09-06 16:09:27'),(19,4,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(20,5,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(21,6,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(22,7,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(23,8,2,2,'2026-09-07',2,'Late','5 minutes late','2026-09-06 16:09:27'),(24,9,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(25,10,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(26,11,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(27,12,2,2,'2026-09-07',2,'Absent',NULL,'2026-09-06 16:09:27'),(28,13,2,2,'2026-09-07',2,'Leave','Approved leave','2026-09-06 16:09:27'),(29,14,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27'),(30,15,2,2,'2026-09-07',2,'Present',NULL,'2026-09-06 16:09:27');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-08 20:00:32
