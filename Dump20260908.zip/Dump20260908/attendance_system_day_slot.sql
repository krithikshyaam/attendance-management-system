-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: attendance_system
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `day_slot`
--

DROP TABLE IF EXISTS `day_slot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `day_slot` (
  `slot_order` tinyint NOT NULL,
  `slot_type` enum('PERIOD','BREAK','LUNCH') NOT NULL,
  `slot_name` varchar(30) NOT NULL,
  `period_no` tinyint DEFAULT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  PRIMARY KEY (`slot_order`),
  KEY `fk_day_slot_period` (`period_no`),
  CONSTRAINT `fk_day_slot_period` FOREIGN KEY (`period_no`) REFERENCES `period_master` (`period_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `day_slot`
--

LOCK TABLES `day_slot` WRITE;
/*!40000 ALTER TABLE `day_slot` DISABLE KEYS */;
INSERT INTO `day_slot` VALUES (1,'PERIOD','Period 1',1,'09:00:00','09:50:00'),(2,'PERIOD','Period 2',2,'09:50:00','10:40:00'),(3,'BREAK','Break 1',NULL,'10:40:00','10:55:00'),(4,'PERIOD','Period 3',3,'10:55:00','11:45:00'),(5,'PERIOD','Period 4',4,'11:45:00','12:35:00'),(6,'LUNCH','Lunch',NULL,'12:35:00','13:20:00'),(7,'PERIOD','Period 5',5,'13:20:00','14:10:00'),(8,'PERIOD','Period 6',6,'14:10:00','15:00:00'),(9,'BREAK','Break 2',NULL,'15:00:00','15:10:00'),(10,'PERIOD','Period 7',7,'15:10:00','16:00:00');
/*!40000 ALTER TABLE `day_slot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-08 20:00:31
