-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: attendance_system
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `period_timetable`
--

DROP TABLE IF EXISTS `period_timetable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `period_timetable` (
  `timetable_id` int NOT NULL AUTO_INCREMENT,
  `class_id` int NOT NULL,
  `day_of_week` enum('MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY') NOT NULL,
  `period_no` tinyint NOT NULL,
  `subject_id` int NOT NULL,
  `teacher_id` int NOT NULL,
  `room_no` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`timetable_id`),
  UNIQUE KEY `class_id` (`class_id`,`day_of_week`,`period_no`),
  KEY `fk_timetable_period` (`period_no`),
  KEY `fk_timetable_subject` (`subject_id`),
  KEY `fk_timetable_teacher` (`teacher_id`),
  CONSTRAINT `fk_timetable_class` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`),
  CONSTRAINT `fk_timetable_period` FOREIGN KEY (`period_no`) REFERENCES `period_master` (`period_no`),
  CONSTRAINT `fk_timetable_subject` FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`),
  CONSTRAINT `fk_timetable_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `period_timetable`
--

LOCK TABLES `period_timetable` WRITE;
/*!40000 ALTER TABLE `period_timetable` DISABLE KEYS */;
INSERT INTO `period_timetable` VALUES (1,1,'MONDAY',1,1,1,'CSE-101'),(2,1,'MONDAY',2,2,2,'CSE-101'),(3,1,'MONDAY',3,3,3,'CSE-101'),(4,1,'MONDAY',4,4,4,'CSE-101'),(5,1,'MONDAY',5,5,5,'CSE-101'),(6,1,'MONDAY',6,6,6,'CSE-101'),(7,1,'MONDAY',7,7,7,'CSE-101'),(8,1,'TUESDAY',1,2,2,'CSE-101'),(9,1,'TUESDAY',2,3,3,'CSE-101'),(10,1,'TUESDAY',3,4,4,'CSE-101'),(11,1,'TUESDAY',4,5,5,'CSE-101'),(12,1,'TUESDAY',5,6,6,'CSE-101'),(13,1,'TUESDAY',6,7,7,'CSE-101'),(14,1,'TUESDAY',7,1,1,'CSE-101'),(15,1,'WEDNESDAY',1,3,3,'CSE-101'),(16,1,'WEDNESDAY',2,4,4,'CSE-101'),(17,1,'WEDNESDAY',3,5,5,'CSE-101'),(18,1,'WEDNESDAY',4,6,6,'CSE-101'),(19,1,'WEDNESDAY',5,7,7,'CSE-101'),(20,1,'WEDNESDAY',6,1,1,'CSE-101'),(21,1,'WEDNESDAY',7,2,2,'CSE-101'),(22,1,'THURSDAY',1,4,4,'CSE-101'),(23,1,'THURSDAY',2,5,5,'CSE-101'),(24,1,'THURSDAY',3,6,6,'CSE-101'),(25,1,'THURSDAY',4,7,7,'CSE-101'),(26,1,'THURSDAY',5,1,1,'CSE-101'),(27,1,'THURSDAY',6,2,2,'CSE-101'),(28,1,'THURSDAY',7,3,3,'CSE-101'),(29,1,'FRIDAY',1,5,5,'CSE-101'),(30,1,'FRIDAY',2,6,6,'CSE-101'),(31,1,'FRIDAY',3,7,7,'CSE-101'),(32,1,'FRIDAY',4,1,1,'CSE-101'),(33,1,'FRIDAY',5,2,2,'CSE-101'),(34,1,'FRIDAY',6,3,3,'CSE-101'),(35,1,'FRIDAY',7,4,4,'CSE-101');
/*!40000 ALTER TABLE `period_timetable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-08 20:00:33
