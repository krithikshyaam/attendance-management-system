-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: attendance_system
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `student_id` int NOT NULL,
  `roll_no` varchar(20) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `department_id` int NOT NULL,
  `class_id` int NOT NULL,
  `admission_year` int NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `roll_no` (`roll_no`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_student_department` (`department_id`),
  KEY `fk_student_class` (`class_id`),
  CONSTRAINT `fk_student_class` FOREIGN KEY (`class_id`) REFERENCES `class` (`class_id`),
  CONSTRAINT `fk_student_department` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (1,'23CS001','Arun Kumar','arun@college.edu','9000000001','Male',1,1,2023,1),(2,'23CS002','Bala S','bala@college.edu','9000000002','Male',1,1,2023,1),(3,'23CS003','Divya R','divya@college.edu','9000000003','Female',1,1,2023,1),(4,'23CS004','Ganesh P','ganesh@college.edu','9000000004','Male',1,1,2023,1),(5,'23CS005','Harini K','harini@college.edu','9000000005','Female',1,1,2023,1),(6,'23CS006','Irfan A','irfan@college.edu','9000000006','Male',1,1,2023,1),(7,'23CS007','Janani M','janani@college.edu','9000000007','Female',1,1,2023,1),(8,'23CS008','Karthik R','karthik@college.edu','9000000008','Male',1,1,2023,1),(9,'23CS009','Lavanya S','lavanya@college.edu','9000000009','Female',1,1,2023,1),(10,'23CS010','Manoj K','manoj@college.edu','9000000010','Male',1,1,2023,1),(11,'23CS011','Nandhini P','nandhini@college.edu','9000000011','Female',1,1,2023,1),(12,'23CS012','Praveen T','praveen@college.edu','9000000012','Male',1,1,2023,1),(13,'23CS013','Revathi G','revathi@college.edu','9000000013','Female',1,1,2023,1),(14,'23CS014','Sanjay V','sanjay@college.edu','9000000014','Male',1,1,2023,1),(15,'23CS015','Swetha N','swetha@college.edu','9000000015','Female',1,1,2023,1);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-08 20:00:30
