-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: attendance_system
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `weekly_timetable_view`
--

DROP TABLE IF EXISTS `weekly_timetable_view`;
/*!50001 DROP VIEW IF EXISTS `weekly_timetable_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `weekly_timetable_view` AS SELECT 
 1 AS `department_code`,
 1 AS `class_id`,
 1 AS `class_name`,
 1 AS `day_of_week`,
 1 AS `period_no`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `subject_code`,
 1 AS `subject_name`,
 1 AS `teacher_code`,
 1 AS `teacher_name`,
 1 AS `room_no`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `attendance_detail_view`
--

DROP TABLE IF EXISTS `attendance_detail_view`;
/*!50001 DROP VIEW IF EXISTS `attendance_detail_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `attendance_detail_view` AS SELECT 
 1 AS `attendance_id`,
 1 AS `student_id`,
 1 AS `roll_no`,
 1 AS `student_name`,
 1 AS `attendance_date`,
 1 AS `period_no`,
 1 AS `period_name`,
 1 AS `start_time`,
 1 AS `end_time`,
 1 AS `subject_code`,
 1 AS `subject_name`,
 1 AS `teacher_code`,
 1 AS `teacher_name`,
 1 AS `status`,
 1 AS `remarks`,
 1 AS `marked_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `student_attendance_percentage_view`
--

DROP TABLE IF EXISTS `student_attendance_percentage_view`;
/*!50001 DROP VIEW IF EXISTS `student_attendance_percentage_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `student_attendance_percentage_view` AS SELECT 
 1 AS `student_id`,
 1 AS `roll_no`,
 1 AS `student_name`,
 1 AS `total_periods`,
 1 AS `attended_periods`,
 1 AS `attendance_percentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `student_subject_percentage_view`
--

DROP TABLE IF EXISTS `student_subject_percentage_view`;
/*!50001 DROP VIEW IF EXISTS `student_subject_percentage_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `student_subject_percentage_view` AS SELECT 
 1 AS `student_id`,
 1 AS `roll_no`,
 1 AS `student_name`,
 1 AS `subject_id`,
 1 AS `subject_code`,
 1 AS `subject_name`,
 1 AS `total_periods`,
 1 AS `attended_periods`,
 1 AS `attendance_percentage`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `weekly_timetable_view`
--

/*!50001 DROP VIEW IF EXISTS `weekly_timetable_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `weekly_timetable_view` AS select `d`.`department_code` AS `department_code`,`c`.`class_id` AS `class_id`,concat(`c`.`class_name`,'-',`c`.`section`) AS `class_name`,`pt`.`day_of_week` AS `day_of_week`,`pt`.`period_no` AS `period_no`,`pm`.`start_time` AS `start_time`,`pm`.`end_time` AS `end_time`,`sub`.`subject_code` AS `subject_code`,`sub`.`subject_name` AS `subject_name`,`t`.`teacher_code` AS `teacher_code`,`t`.`teacher_name` AS `teacher_name`,`pt`.`room_no` AS `room_no` from (((((`period_timetable` `pt` join `class` `c` on((`c`.`class_id` = `pt`.`class_id`))) join `department` `d` on((`d`.`department_id` = `c`.`department_id`))) join `period_master` `pm` on((`pm`.`period_no` = `pt`.`period_no`))) join `subject` `sub` on((`sub`.`subject_id` = `pt`.`subject_id`))) join `teacher` `t` on((`t`.`teacher_id` = `pt`.`teacher_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `attendance_detail_view`
--

/*!50001 DROP VIEW IF EXISTS `attendance_detail_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `attendance_detail_view` AS select `a`.`attendance_id` AS `attendance_id`,`s`.`student_id` AS `student_id`,`s`.`roll_no` AS `roll_no`,`s`.`student_name` AS `student_name`,`a`.`attendance_date` AS `attendance_date`,`a`.`period_no` AS `period_no`,`pm`.`period_name` AS `period_name`,`pm`.`start_time` AS `start_time`,`pm`.`end_time` AS `end_time`,`sub`.`subject_code` AS `subject_code`,`sub`.`subject_name` AS `subject_name`,`t`.`teacher_code` AS `teacher_code`,`t`.`teacher_name` AS `teacher_name`,`a`.`status` AS `status`,`a`.`remarks` AS `remarks`,`a`.`marked_at` AS `marked_at` from ((((`attendance` `a` join `student` `s` on((`s`.`student_id` = `a`.`student_id`))) join `period_master` `pm` on((`pm`.`period_no` = `a`.`period_no`))) join `subject` `sub` on((`sub`.`subject_id` = `a`.`subject_id`))) join `teacher` `t` on((`t`.`teacher_id` = `a`.`teacher_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `student_attendance_percentage_view`
--

/*!50001 DROP VIEW IF EXISTS `student_attendance_percentage_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `student_attendance_percentage_view` AS select `s`.`student_id` AS `student_id`,`s`.`roll_no` AS `roll_no`,`s`.`student_name` AS `student_name`,count(`a`.`attendance_id`) AS `total_periods`,sum((case when (`a`.`status` in ('Present','Late')) then 1 else 0 end)) AS `attended_periods`,round(((sum((case when (`a`.`status` in ('Present','Late')) then 1 else 0 end)) * 100.0) / count(`a`.`attendance_id`)),2) AS `attendance_percentage` from (`student` `s` join `attendance` `a` on((`a`.`student_id` = `s`.`student_id`))) group by `s`.`student_id`,`s`.`roll_no`,`s`.`student_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `student_subject_percentage_view`
--

/*!50001 DROP VIEW IF EXISTS `student_subject_percentage_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `student_subject_percentage_view` AS select `s`.`student_id` AS `student_id`,`s`.`roll_no` AS `roll_no`,`s`.`student_name` AS `student_name`,`sub`.`subject_id` AS `subject_id`,`sub`.`subject_code` AS `subject_code`,`sub`.`subject_name` AS `subject_name`,count(`a`.`attendance_id`) AS `total_periods`,sum((case when (`a`.`status` in ('Present','Late')) then 1 else 0 end)) AS `attended_periods`,round(((sum((case when (`a`.`status` in ('Present','Late')) then 1 else 0 end)) * 100.0) / count(`a`.`attendance_id`)),2) AS `attendance_percentage` from ((`student` `s` join `attendance` `a` on((`a`.`student_id` = `s`.`student_id`))) join `subject` `sub` on((`sub`.`subject_id` = `a`.`subject_id`))) group by `s`.`student_id`,`s`.`roll_no`,`s`.`student_name`,`sub`.`subject_id`,`sub`.`subject_code`,`sub`.`subject_name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-08 20:00:33
